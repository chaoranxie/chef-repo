## v1.1.0:

* [COOK-1663] - Configurable ListenAddress based off list of interface
  names
* [COOK-1685] - Make default sshd_config value more robust

## v1.0.0:

* [COOK-1014] - Templates for ssh(d).conf files.

## v0.8.1:

* Current public release
