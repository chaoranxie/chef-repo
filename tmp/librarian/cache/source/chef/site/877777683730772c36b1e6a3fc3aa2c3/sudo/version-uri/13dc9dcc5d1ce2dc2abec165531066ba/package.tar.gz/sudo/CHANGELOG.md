## v1.2.0:

* [COOK-1314] - default package action is now :install instead of :upgrade
* [COOK-1549] - Preserve SSH agent credentials upon sudo using an attribute

## v1.1.0:

* [COOK-350] - LWRP to manage sudo files via includedir (/etc/sudoers.d)

## v1.0.2:

* [COOK-903] - freebsd support
